<?php
header('Content-Type: text/html;charset=UTF-8');
?>
<div class="floors">
				<div class="lf">
					<p>7F&nbsp;&nbsp;电脑数码</p>
					<p class="hot_active">热门活动</p>
					<p class="cai">热卖商品		<span></span>
					</p>
				</div>
				<ul class="rt">
					<li><a href="#">iPad</a></li>
					<li><a href="#"  class="se">笔记本</a></li>
					<li><a href="#">台式机</a></li>
					<li><a href="#">DIV</a></li>
					<li><a href="#" class="se">单反</a></li>
					<li><a href="#">微单</a></li>
					<li><a href="#">佳能</a></li>
					<li><a href="#">尼康</a></li>
				</ul>
			</div>
			<div class="image">
				<div class="d1 lf">
					<a href="#"><img src="img/144726714612692357.jpg"/></a>
				</div>
				<div class="d1 lf two">
					<a href="#"><img src="img/144724980856882765.jpg"/></a>
				</div>
				<ul class="lf tu1">
					<li><a href="#"><img src="img/144715688017825552.jpg"/></a></li>
					<li><a href="#"><img src="img/144699344643859415.jpg"/></a></li>
					<li><a href="#"><img src="img/144725442408688137.jpg"/></a></li>
					<li><a href="#"><img src="img/144724982656684766.jpg"/></a></li>
				</ul>
				<ul class="lf tu2">
					<li><a href="#"><img src="img/144707808070686572.jpg"/></a></li>
					<li><a href="#"><img src="img/144725250471486429.jpg"/></a></li>
					<li><a href="#"><img src="img/144724988067342423.jpg"/></a></li>
				</ul>
			</div>