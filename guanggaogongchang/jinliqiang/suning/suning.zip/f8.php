<?php
header('Content-Type: text/html;charset=UTF-8');
?>
<div class="floors">
				<div class="lf">
					<p>8F&nbsp;&nbsp;生活电器</p>
					<p class="hot_active">热门活动</p>
					<p class="cai">热卖商品		<span></span>
					</p>
				</div>
				<ul class="rt">
					<li><a href="#">电热饭盒</a></li>
					<li><a href="#"  class="se">微波炉</a></li>
					<li><a href="#">取暖电器</a></li>
					<li><a href="#">电吹风</a></li>
					<li><a href="#">足浴盆</a></li>
					<li><a href="#">电压力锅</a></li>
					<li><a href="#">电饭煲</a></li>
				</ul>
			</div>
			<div class="image">
				<div class="d1 lf">
					<a href="#"><img src="img/144705256389856428.jpg"/></a>
				</div>
				<div class="d1 lf two">
					<a href="#"><img src="img/144720885488915147.jpg"/></a>
				</div>
				<ul class="lf tu1">
					<li><a href="#"><img src="img/144716641778263391.jpg"/></a></li>
					<li><a href="#"><img src="img/144705180576638632.jpg"/></a></li>
					<li><a href="#"><img src="img/144705215139253635.jpg"/></a></li>
					<li><a href="#"><img src="img/144453118467387788.jpg"/></a></li>
				</ul>
				<ul class="lf tu2">
					<li><a href="#"><img src="img/144705222094834774.jpg"/></a></li>
					<li><a href="#"><img src="img/144705217119308434.jpg"/></a></li>
					<li><a href="#"><img src="img/144705209533648620.jpg"/></a></li>
				</ul>
			</div>