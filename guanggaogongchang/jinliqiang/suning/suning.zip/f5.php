<?php
header('Content-Type: text/html;charset=UTF-8');
?>
<div class="floors">
				<div class="lf">
					<p>5F&nbsp;&nbsp;母婴玩具</p>
					<p class="hot_active">热门活动</p>
					<p class="cai">热卖商品		<span></span>
					</p>
				</div>
				<ul class="rt">
					<li><a href="#" class="se">大牌奶粉</a></li>
					<li><a href="#">婴儿推车</a></li>
					<li><a href="#">儿童保温杯</a></li>
					<li><a href="#" class="se">好奇</a></li>
					<li><a href="#">孕妇装</a></li>
					<li><a href="#" class="se">益智玩具</a></li>
					<li><a href="#">科学育儿</a></li>
				</ul>
			</div>
			<div class="image">
				<div class="d1 lf">
					<a href="#"><img src="img/144714774703373182.jpg"/></a>
				</div>
				<div class="d1 lf two">
					<a href="#"><img src="img/144706333523781475.jpg"/></a>
				</div>
				<ul class="lf tu1">
					<li><a href="#"><img src="img/144653964721885372.jpg"/></a></li>
					<li><a href="#"><img src="img/144714729734285108.jpg"/></a></li>
					<li><a href="#"><img src="img/144706338551326626.jpg"/></a></li>
					<li><a href="#"><img src="img/144315156571938131.jpg"/></a></li>
				</ul>
				<ul class="lf tu2">
					<li><a href="#"><img src="img/144706348668344373.jpg"/></a></li>
					<li><a href="#"><img src="img/144711792155841053.jpg"/></a></li>
					<li><a href="#"><img src="img/144706341278673632.jpg"/></a></li>
				</ul>
			</div>
