<?php
header('Content-Type: text/html;charset=UTF-8');
?>
<div class="floors">
				<div class="lf">
					<p>3F&nbsp;&nbsp;生活日常</p>
					<p class="hot_active">热门活动</p>
					<p class="cai">热卖商品		<span></span>
					</p>
				</div>
				<ul class="rt">
					<li><a href="#" class="se">洗衣液</a></li>
					<li><a href="#">四件套</a></li>
					<li><a href="#">保温杯</a></li>
					<li><a href="#">卷纸</a></li>
					<li><a href="#" class="se">安全避孕</a></li>
					<li><a href="#">被子</a></li>
					<li><a href="#">抽纸</a></li>
					<li><a href="#">衣物洗护</a></li>
				</ul>
			</div>
			<div class="image">
				<div class="d1 lf">
					<a href="#"><img src="img/144703141855615828.jpg"/></a>
				</div>
				<div class="d1 lf two">
					<a href="#"><img src="img/144729391354612913.jpg"/></a>
				</div>
				<ul class="lf tu1">
					<li><a href="#"><img src="img/144729398000661393.jpg"/></a></li>
					<li><a href="#"><img src="img/144706670978787124.jpg"/></a></li>
					<li><a href="#"><img src="img/144716560128264733.jpg"/></a></li>
					<li><a href="#"><img src="img/144706251354145116.jpg"/></a></li>
				</ul>
				<ul class="lf tu2">
					<li><a href="#"><img src="img/144706702686208710.jpg"/></a></li>
					<li><a href="#"><img src="img/144706681647544553.jpg"/></a></li>
					<li><a href="#"><img src="img/144706691547426755.jpg"/></a></li>
				</ul>
			</div>