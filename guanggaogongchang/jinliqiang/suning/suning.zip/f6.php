<?php
header('Content-Type: text/html;charset=UTF-8');
?>
<div class="floors">
				<div class="lf">
					<p>6F&nbsp;&nbsp;美妆个护</p>
					<p class="hot_active">热门活动</p>
					<p class="cai">热卖商品		<span></span>
					</p>
				</div>
				<ul class="rt">
					<li><a href="#" class="se">面膜</a></li>
					<li><a href="#">洗面奶</a></li>
					<li><a href="#">水乳</a></li>
					<li><a href="#">彩妆</a></li>
					<li><a href="#">洗发水</a></li>
					<li><a href="#">沐浴露</a></li>
					<li><a href="#">牙膏</a></li>
					<li><a href="#"  class="se">卫生巾</a></li>
				</ul>
			</div>
			<div class="image">
				<div class="d1 lf">
					<a href="#"><img src="img/144729463076350104.jpg"/></a>
				</div>
				<div class="d1 lf two">
					<a href="#"><img src="img/144723080476458844.jpg"/></a>
				</div>
				<ul class="lf tu1">
					<li><a href="#"><img src="img/144671270077826015.jpg"/></a></li>
					<li><a href="#"><img src="img/144723089317745258.jpg"/></a></li>
					<li><a href="#"><img src="img/144723093605224448.jpg"/></a></li>
					<li><a href="#"><img src="img/144713739547229561.jpg"/></a></li>
				</ul>
				<ul class="lf tu2">
					<li><a href="#"><img src="img/144723097421488879.jpg"/></a></li>
					<li><a href="#"><img src="img/144723578710161242.jpg"/></a></li>
					<li><a href="#"><img src="img/144714110798424669.jpg"/></a></li>
				</ul>
			</div>