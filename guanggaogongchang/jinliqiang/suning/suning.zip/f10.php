<?php
header('Content-Type: text/html;charset=UTF-8');
?>
<div class="floors">
				<div class="lf">
					<p>10F&nbsp;&nbsp;家装建材</p>
					<p class="hot_active">热门活动</p>
					<p class="cai">热卖商品		<span></span>
					</p>
				</div>
				<ul class="rt">
					<li><a href="#">沙发</a></li>
					<li><a href="#"  class="se">客厅灯</a></li>
					<li><a href="#">插座</a></li>
					<li><a href="#">沐浴花酒</a></li>
					<li><a href="#">水槽</a></li>
					<li><a href="#">欧式吊灯</a></li>
					<li><a href="#">床</a></li>
					<li><a href="#"  class="se">坐便器</a></li>
				</ul>
			</div>
			<div class="image">
				<div class="d1 lf">
					<a href="#"><img src="img/144706524709840387.jpg"/></a>
				</div>
				<div class="d1 lf two">
					<a href="#"><img src="img/144670949397353643.jpg"/></a>
				</div>
				<ul class="lf tu1">
					<li><a href="#"><img src="img/144717338743037970.jpg"/></a></li>
					<li><a href="#"><img src="img/144706851271676341.jpg"/></a></li>
					<li><a href="#"><img src="img/144619310809725723.jpg"/></a></li>
					<li><a href="#"><img src="img/144660958290455215.jpg"/></a></li>
				</ul>
				<ul class="lf tu2">
					<li><a href="#"><img src="img/144671650320966182.jpg"/></a></li>
					<li><a href="#"><img src="img/144584918074590367.jpg"/></a></li>
					<li><a href="#"><img src="img/144724002982724668.jpg"/></a></li>
				</ul>
			</div>