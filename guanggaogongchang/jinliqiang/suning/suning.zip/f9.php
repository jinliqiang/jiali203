<?php
header('Content-Type: text/html;charset=UTF-8');
?>
<div class="floors">
				<div class="lf">
					<p>9F&nbsp;&nbsp;家用电器</p>
					<p class="hot_active">热门活动</p>
					<p class="cai">热卖商品		<span></span>
					</p>
				</div>
				<ul class="rt">
					<li><a href="#">洗衣机</a></li>
					<li><a href="#"  class="se">电视</a></li>
					<li><a href="#" class="se">厨卫电器</a></li>
					<li><a href="#">空调</a></li>
					<li><a href="#">变频空调</a></li>
					<li><a href="#">热水器</a></li>
					<li><a href="#">海信电视</a></li>
					<li><a href="#"  class="se">冰箱</a></li>
				</ul>
			</div>
			<div class="image">
				<div class="d1 lf">
					<a href="#"><img src="img/144721118603415477.jpg"/></a>
				</div>
				<div class="d1 lf two">
					<a href="#"><img src="img/144672522787779838.jpg"/></a>
				</div>
				<ul class="lf tu1">
					<li><a href="#"><img src="img/144717102212914262.jpg"/></a></li>
					<li><a href="#"><img src="img/144725244154511247.jpg"/></a></li>
					<li><a href="#"><img src="img/144724070890231865.jpg"/></a></li>
					<li><a href="#"><img src="img/144453118467387788.jpg"/></a></li>
				</ul>
				<ul class="lf tu2">
					<li><a href="#"><img src="img/144725250471486429.jpg"/></a></li>
					<li><a href="#"><img src="img/144723443569083465.jpg"/></a></li>
					<li><a href="#"><img src="img/144723451433977413.jpg"/></a></li>
				</ul>
			</div>