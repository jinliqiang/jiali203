<?php
header('Content-Type: text/html;charset=UTF-8');
?>
<div class="floors">
    <div class="lf">
		<p>1F&nbsp;&nbsp;服饰百货</p>
		<p class="hot_active">热门活动</p>
		<p class="cai">猜你喜欢		<span></span>
		</p>
	</div>
	<ul class="rt">
		<li><a href="#">女士羽绒服</a></li>
		<li><a href="#" >男士针织衫</a></li>
		<li><a href="#">保暖内衣</a></li>
		<li><a href="#">雪地靴</a></li>
		<li><a href="#">钱包卡包</a></li>
		<li><a href="#">黄金</a></li>
		<li><a href="#">手表</a></li>
		<li><a href="#" >冲锋衣</a></li>
	</ul>
</div>
<div class="image">
	<div class="d1 lf">
		<a href="#"><img src="imag/144698208894455869.jpg"/></a>
	</div>
	<div class="d1 lf two">
		<a href="#"><img src="imag/144723179244204522.jpg"/></a>
	</div>
	<ul class="lf tu1">
		<li><a href="#"><img src="imag/144731257376228455.jpg"/></a></li>
		<li><a href="#"><img src="imag/144721404833011214.jpg"/></a></li>
		<li><a href="#"><img src="imag/144678936235682957.jpg"/></a></li>
		<li><a href="#"><img src="imag/144453118467387788.jpg"/></a></li>
	</ul>
	<ul class="lf tu2">
		<li><a href="#"><img src="imag/144698198279746426.jpg"/></a></li>
		<li><a href="#"><img src="imag/144723578710161242.jpg"/></a></li>
		<li><a href="#"><img src="imag/144695029970606539.jpg"/></a></li>
	</ul>
</div>