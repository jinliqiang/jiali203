<?php
header('Content-Type: text/html;charset=UTF-8');
?>
<div class="floors">
				<div class="lf">
					<p>4F&nbsp;&nbsp;食品酒水</p>
					<p class="hot_active">热门活动</p>
					<p class="cai">热卖商品		<span></span>
					</p>
				</div>
				<ul class="rt">
					<li><a href="#" class="se">大米</a></li>
					<li><a href="#">牛奶乳品</a></li>
					<li><a href="#">饼干糕点</a></li>
					<li><a href="#">食用油</a></li>
					<li><a href="#">白酒</a></li>
					<li><a href="#">零食</a></li>
					<li><a href="#">进口休闲</a></li>
					<li><a href="#"  class="se">酸奶</a></li>
				</ul>
			</div>
			<div class="image">
				<div class="d1 lf">
					<a href="#"><img src="img/144714861198541990.jpg"/></a>
				</div>
				<div class="d1 lf two">
					<a href="#"><img src="img/144719175261668052.jpg"/></a>
				</div>
				<ul class="lf tu1">
					<li><a href="#"><img src="img/144729231070272574.jpg"/></a></li>
					<li><a href="#"><img src="img/144705256996123443.jpg"/></a></li>
					<li><a href="#"><img src="img/144714364838780345.jpg"/></a></li>
					<li><a href="#"><img src="img/144719180974875935.jpg"/></a></li>
				</ul>
				<ul class="lf tu2">
					<li><a href="#"><img src="img/144729257274824520.jpg"/></a></li>
					<li><a href="#"><img src="img/144714378081335720.jpg"/></a></li>
					<li><a href="#"><img src="img/144705219410107637.jpg"/></a></li>
				</ul>
			</div>